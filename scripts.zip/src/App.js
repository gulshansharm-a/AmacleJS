import React, { useState, useEffect } from 'react';
import Test from './Amacle/Models/Test'
const App = () => {
  const [posts, setPosts] = useState([]);

  useEffect(async () => {
    
    const  t= new Test()
    const result =await t.select("*").where("employee_id",">","1").orderBy("salary").get();
    setPosts(result)

  },
  []); 

  return (
    <div>
      <h1>Posts</h1>
      <pre>{JSON.stringify(posts, null, 2)}</pre>
    </div>
  );
};

export default App;
