// Blueprint.js

/**
 * Blueprint class for defining and manipulating database table schemas.
 * 
 * @class
 */
class Blueprint {
    /**
     * Constructor for creating a new Blueprint instance.
     * Initializes arrays to store columns, table options, indexes, and the table name.
     */
    constructor() {
        this.columns = [];      // Array to store column definitions
        this.tableOptions = []; // Array to store table options
        this.tablename = null;   // Variable to store the table name
        this.indexes = [];       // Array to store index definitions
    }

    /**
     * Adds a new column to the blueprint.
     * 
     * @param {string} name - The name of the column.
     * @param {string} type - The data type of the column.
     * @param {Object} [options={}] - Additional options for the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    column(name, type, options = {}) {
        this.columns.push({ name, type, options });
        return this;
    }

    /**
     * Sets the name of the table.
     * 
     * @param {string} tablename - The name of the table.
     */
    name(tablename) {
        this.tablename = tablename;
    }

    /**
     * Generates SQL statements for creating a new table based on defined columns.
     * 
     * @returns {Array} - Array of SQL statements for creating the table.
     */
    create() {
        // Logic to generate SQL statements for creating a table based on columns
        return this.columns;
    }

    /**
     * Generates SQL statements for altering an existing table based on defined columns.
     * 
     * @returns {Array} - Array of SQL statements for altering the table.
     */
    alter() {
        // Logic to generate SQL statements for altering a table based on columns
        return this.columns;
    }

    // Index methods

    /**
     * Adds a primary index on specified columns.
     * 
     * @param {string|string[]} columns - The column(s) to include in the primary index.
     * @param {string|null} [indexName=null] - The name of the primary index.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    primary(columns, indexName = null) {
        this.indexes.push({
            type: 'primary',
            columns: Array.isArray(columns) ? columns : [columns],
            name: indexName,
        });
        return this;
    }

    /**
     * Adds a unique index on specified columns.
     * 
     * @param {string|string[]} columns - The column(s) to include in the unique index.
     * @param {string|null} [indexName=null] - The name of the unique index.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    unique(columns, indexName = null) {
        this.indexes.push({
            type: 'unique',
            columns: Array.isArray(columns) ? columns : [columns],
            name: indexName,
        });
        return this;
    }

    /**
     * Adds a regular index on specified columns.
     * 
     * @param {string|string[]} columns - The column(s) to include in the regular index.
     * @param {string|null} [indexName=null] - The name of the regular index.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    index(columns, indexName = null) {
        this.indexes.push({
            type: 'index',
            columns: Array.isArray(columns) ? columns : [columns],
            name: indexName,
        });
        return this;
    }

    /**
     * Adds a full-text index on specified columns.
     * 
     * @param {string|string[]} columns - The column(s) to include in the full-text index.
     * @param {string|null} [indexName=null] - The name of the full-text index.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    fullText(columns, indexName = null) {
        this.indexes.push({
            type: 'fullText',
            columns: Array.isArray(columns) ? columns : [columns],
            name: indexName,
        });
        return this;
    }

    /**
     * Adds a spatial index on specified columns.
     * 
     * @param {string|string[]} columns - The column(s) to include in the spatial index.
     * @param {string|null} [indexName=null] - The name of the spatial index.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    spatialIndex(columns, indexName = null) {
        this.indexes.push({
            type: 'spatial',
            columns: Array.isArray(columns) ? columns : [columns],
            name: indexName,
        });
        return this;
    }

    // Column options methods

    /**
     * Sets the column to appear after another column.
     * 
     * @param {string} columnName - The name of the column after which the current column should appear.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    after(columnName) {
        this.columns[this.columns.length - 1].options.after = columnName;
        return this;
    }

    /**
     * Sets whether the column is nullable.
     * 
     * @param {boolean} [value=true] - If true, the column is nullable; otherwise, it's not nullable.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    nullable(value = true) {
        this.columns[this.columns.length - 1].options.nullable = value;
        return this;
    }

    /**
     * Sets the column as auto-incrementing.
     * 
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    autoIncrement() {
        this.columns[this.columns.length - 1].options.autoIncrement = true;
        return this;
    }

    /**
     * Sets the character set for the column.
     * 
     * @param {string} value - The character set for the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    charset(value) {
        this.columns[this.columns.length - 1].options.charset = value;
        return this;
    }

    /**
     * Sets the collation for the column.
     * 
     * @param {string} value - The collation for the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    collation(value) {
        this.columns[this.columns.length - 1].options.collation = value;
        return this;
    }

    /**
     * Sets the comment for the column.
     * 
     * @param {string} value - The comment for the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    comment(value) {
        this.columns[this.columns.length - 1].options.comment = value;
        return this;
    }

    /**
     * Sets the default value for the column.
     * 
     * @param {any} value - The default value for the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    default(value) {
        this.columns[this.columns.length - 1].options.default = value;
        return this;
    }

    // Data types methods

    /**
     * Adds a BIGINT column with auto-incrementing primary key.
     * 
     * @param {string} name - The name of the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    bigIncrements(name) {
        this.column(name, 'BIGINT', { primaryKey: true, autoIncrement: true });
        return this;
    }

    /**
     * Adds a BIGINT column.
     * 
     * @param {string} name - The name of the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    bigInteger(name) {
        this.column(name, 'BIGINT');
        return this;
    }

    /**
     * Adds a BLOB column.
     * 
     * @param {string} name - The name of the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    binary(name) {
        this.column(name, 'BLOB');
        return this;
    }

    /**
     * Adds a BOOLEAN column.
     * 
     * @param {string} name - The name of the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    boolean(name) {
        this.column(name, 'BOOLEAN');
        return this;
    }

    /**
     * Adds a CHAR column with a specified length.
     * 
     * @param {string} name - The name of the column.
     * @param {number} [length=255] - The length of the CHAR column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    char(name, length = 255) {
        this.column(name, `CHAR(${length})`);
        return this;
    }

    /**
     * Adds a TIMESTAMP WITH TIME ZONE column.
     * 
     * @param {string} name - The name of the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    dateTimeTz(name) {
        this.column(name, 'TIMESTAMP WITH TIME ZONE');
        return this;
    }

    /**
     * Adds a DATETIME column.
     * 
     * @param {string} name - The name of the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    dateTime(name) {
        this.column(name, 'DATETIME');
        return this;
    }

    /**
     * Adds a DATE column.
     * 
     * @param {string} name - The name of the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    date(name) {
        this.column(name, 'DATE');
        return this;
    }

    /**
     * Adds a DECIMAL column with specified precision and scale.
     * 
     * @param {string} name - The name of the column.
     * @param {number} [precision=8] - The precision of the DECIMAL column.
     * @param {number} [scale=2] - The scale of the DECIMAL column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    decimal(name, precision = 8, scale = 2) {
        this.column(name, `DECIMAL(${precision},${scale})`);
        return this;
    }

    /**
     * Adds a DOUBLE column with specified precision and scale.
     * 
     * @param {string} name - The name of the column.
     * @param {number} [precision=8] - The precision of the DOUBLE column.
     * @param {number} [scale=2] - The scale of the DOUBLE column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    double(name, precision = 8, scale = 2) {
        this.column(name, `DOUBLE(${precision},${scale})`);
        return this;
    }

    /**
     * Adds an ENUM column with specified values.
     * 
     * @param {string} name - The name of the column.
     * @param {string[]} values - The allowed values for the ENUM column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    enum(name, values) {
        this.column(name, `ENUM(${values.map(value => `'${value}'`).join(',')})`);
        return this;
    }

    /**
     * Adds a FLOAT column.
     * 
     * @param {string} name - The name of the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    float(name) {
        this.column(name, 'FLOAT');
        return this;
    }

    /**
     * Adds a BIGINT column for a foreign key reference.
     * 
     * @param {string} name - The name of the column.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    foreignId(name) {
        this.column(name, 'BIGINT');
        return this;
    }

    /**
     * Adds a BIGINT column for a foreign key reference to another table.
     * Also outputs the SQL statement for adding a foreign key constraint.
     * 
     * @param {string} name - The name of the column.
     * @param {string} foreignTable - The name of the referenced table.
     * @returns {Blueprint} - The Blueprint instance for method chaining.
     */
    foreignIdFor(name, foreignTable) {
        this.column(name, 'BIGINT');
        console.log(`ALTER TABLE ${this.tablename} ADD CONSTRAINT fk_${name} FOREIGN KEY (${name}) REFERENCES ${foreignTable}(id);`);
        return this;
    }

    // ... (continued)

    /**
     * Adds documentation comments for a sample static method (__callStatic) from Laravel.
     * 
     * @param {string} $method - The name of the static method.
     * @param {Array} $parameters - An array of parameters for the static method.
     * @returns {mixed} - The result of the static method call.
     */
    /**
     * Handle dynamic static method calls into the model.
     * @param {string} method - The name of the static method.
     * @param {Array} parameters - An array of parameters for the static method.
     * @returns {mixed} - The result of the static method call.
     */
    static __callStatic(method, parameters) {
        return new static()[method](...parameters);
    }
    
}

module.exports = Blueprint;
