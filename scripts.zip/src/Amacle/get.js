const Test = require("./test");

Test.find(10);
