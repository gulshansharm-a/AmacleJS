const DataAccessLayer = require("./DataAccessLayer");

class Model extends DataAccessLayer {

}
module.exports = Model;
