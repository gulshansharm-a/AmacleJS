const Apis = require("../api/Apis");

class QueryBuilder {
    constructor() {
        this.model = this.constructor.name;
        this.conditions = [];
        this.selectFields = ['*'];
        this.orderByField = null;
        this.takeCount = null;
        this.withTrashed = false;
        this.usesCursor = false;
        this.updates = {};
    }
    delete() {
        const whereClause = this.conditions.length > 0
            ? `WHERE ${this.conditions.map(c => `${c.field} ${c.operator} ${c.value}`).join(' AND ')}`
            : '';
        return `DELETE FROM ${this.model} ${whereClause}`;
    }


    where(field, operator, value) {
        this.conditions.push({ field, operator, value });
        return this;
    }
    sum(field) {
        this.aggregationFunction = `SUM(${field})`;
        return this;
    }

    avg(field) {
        this.aggregationFunction = `AVG(${field})`;
        return this;
    }

    orderBy(field) {
        this.orderByField = field;
        return this;
    }

    take(count) {
        this.takeCount = count;
        return this;
    }

    select(...fields) {
        this.selectFields = fields;
        return this;
    }

    subquery(field, callback) {
        const subqueryBuilder = new QueryBuilder(this.model);
        callback(subqueryBuilder);
        const subquerySql = subqueryBuilder.toSql();

        this.conditions.push({
            field: field,
            operator: 'IN',
            value: `(${subquerySql})`,
        });

        return this;
    }
    async update(updates) {


        const apis = new Apis()

        return await apis.getData(() => {
            this.updates = updates;
            const whereClause = this.conditions.length > 0
                ? `WHERE ${this.conditions.map(c => `${c.field} ${c.operator} ${(c.value)}`).join(' AND ')}`
                : '';

            const updateClause = Object.entries(this.updates).length > 0
                ? `UPDATE ${this.model} SET ${Object.entries(this.updates).map(([field, value]) => `${field} = ${this.quoteValue(value)}`).join(', ')} ${whereClause}`
                : '';

            return ` ${updateClause}`;
        }).then((result) => {
            return result;
        })
    }

    quoteValue(value) {
        return typeof value === 'string' ? `'${value}'` : value;
    }


    addSelect(selectFields) {
        this.selectFields.push(...selectFields);
        return this;
    }

    orderByDesc(field) {
        this.orderByField = `${field} DESC`;
        return this;
    }

    find(id) {
        this.conditions.push({ field: 'id', operator: '=', value: id });
        return this;
    }

    first() {
        this.take(1);
        return this;
    }

    firstOrFail(id) {
        return this.find(id).first();
    }

    findOrFail(id) {
        return this.find(id);
    }

    groupBy(field) {
        this.groupByField = field;
        return this;
    }


    lazy() {
        // Implement lazy loading logic
        return this;
    }

    refresh() {
        // Implement refresh logic
        return this;
    }

    fresh() {
        // Implement fresh logic
        return this;
    }

    findOr(id, callback) {
        // Implement findOr logic
        return this;
    }

    firstOr(id, callback) {
        // Implement firstOr logic
        return this;
    }

    async insert(data) {

        const apis = new Apis()

        return await apis.getData(() => {
            return `INSERT INTO ${this.model} (${Object.keys(data).join(', ')}) VALUES (${Object.values(data).map(value => `'${value}'`).join(', ')})`;
        }).then((result) => {
            return result;
        })


    }


    max(field) {
        // Implement max logic
        return this;
    }

    count() {
        this.isCount = true;
        return this;
    }

    min(field) {
        this.aggregationFunction = `MIN(${field})`;
        return this;
    }

    max(field) {
        this.aggregationFunction = `MAX(${field})`;
        return this;
    }

    count(field) {
        this.aggregationFunction = `COUNT(${field || '*'})`;
        return this;
    }

    async getQB() {
        const apis = new Apis()

        return await apis.getData(() => {
            return this.toSql()
        }).then((result) => {
            return result;
        })
    }


    toSql() {
        const selectClause = this.isCount ? 'SELECT COUNT(*)' :
            (this.aggregationFunction ? `SELECT ${this.aggregationFunction}` : `SELECT ${this.selectFields.join(', ')}`);
        const fromClause = `FROM ${this.model}`;
        const whereClause = this.conditions.length > 0
            ? `WHERE ${this.conditions.map(c => `${c.field} ${c.operator} ${c.value}`).join(' AND ')}`
            : '';
        const orderByClause = this.orderByField ? `ORDER BY ${this.orderByField}` : '';
        const takeClause = this.takeCount ? `LIMIT ${this.takeCount}` : '';
        const withTrashedClause = this.withTrashed ? 'WITH TRASHED' : '';
        const cursorClause = this.usesCursor ? 'USE CURSOR' : '';

        const groupByClause = this.groupByField ? `GROUP BY ${this.groupByField}` : '';

        // Clear aggregation function for the next query
        this.aggregationFunction = null;
        console.log(`${selectClause} ${fromClause} ${whereClause} ${groupByClause} ${orderByClause} ${takeClause} ${withTrashedClause} ${cursorClause}`)
        return `${selectClause} ${fromClause} ${whereClause} ${groupByClause} ${orderByClause} ${takeClause} ${withTrashedClause} ${cursorClause}`;
    }
}

module.exports = QueryBuilder;