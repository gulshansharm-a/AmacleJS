class Apis {
    static create_database(col = () => { }) {
        this.create_table_api = 'http://localhost:3000/createtable';
        try {

            fetch(this.create_table_api, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ data: col() })
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    data;
                })
                .catch(error => {
                    console.error('Error sending data:', error.message);
                });

            return Promise.resolve('Request sent successfully');
        } catch (error) {
            console.error('Error sending data:', error.message);
            return Promise.reject(error);
        }
    }

    async getData(dataFromBlueprint) {
        const apiUrl = 'http://localhost:3000/getData';
    
        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ data:await dataFromBlueprint() }),
            });
    
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
    
            const data = await response.json();
            console.log("from api ",data)
            return await data.data;
        } catch (error) {
            console.error('Fetch error:', error);
            throw error;
        }
    }
    

    static OtherActions(col = () => { }) {
        this.create_table_api = 'http://localhost:3000/createtable';
        try {

            fetch(this.create_table_api, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ data: col() })
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Network response was not ok');
                    }
                    return response.json();
                })
                .then(data => {
                    data;
                })
                .catch(error => {
                    console.error('Error sending data:', error.message);
                });

            return Promise.resolve('Request sent successfully');
        } catch (error) {
            console.error('Error sending data:', error.message);
            return Promise.reject(error);
        }
    }


    //ArunStart

    // static createIndex(functionFromBluePrint) {
    //    (functionFromBluePrint())

    // }

    // static dropTable(functionFromBluePrint) {
    //    (functionFromBluePrint());

    // }

    // static dropTableIfExists(functionFromBluePrint) {
    //    (functionFromBluePrint())

    // }

    // static dropIndex(functionFromBluePrint) {
    //    (functionFromBluePrint())

    // }

    // static alterAddColumn(functionFromBluePrint) {
    //    (functionFromBluePrint())

    // }

    // static alterModifyColumn(functionFromBluePrint) {
    //    (functionFromBluePrint())

    // }

    // static alterRenameColumn(functionFromBluePrint) {
    //    (functionFromBluePrint())

    // }

    // static alterAddConstraint(functionFromBluePrint) {
    //    (functionFromBluePrint())

    // }
}

module.exports = Apis;
