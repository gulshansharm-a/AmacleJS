const express = require('express');
const dotenv = require('dotenv');
const helmet = require('helmet');
const { body, validationResult } = require('express-validator');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

class Router {
  constructor() {}

  // Adjusted to invoke the main method correctly
  static use(path, middleware) {
    app.use(path, (req, res, next) => middleware.main(req, res, next));
  }

  // Adjusted to invoke the main method correctly
  static get(path, handlers) {
    app.get(path, (req, res) => handlers.main(req, res));
  }

  // Adjusted to invoke the main method correctly
  static post(path, handlers) {
    app.post(path, (req, res) => handlers.main(req, res));
  }

  // Adjusted to invoke the main method correctly
  static put(path, handlers) {
    app.put(path, (req, res) => handlers.main(req, res));
  }

  // Adjusted to invoke the main method correctly
  static delete(path, handlers) {
    app.delete(path, (req, res) => handlers.main(req, res));
  }

  // Adjusted to invoke the main method correctly
  static patch(path, handlers) {
    app.patch(path, (req, res) => handlers.main(req, res));
  }

  // Adjusted to invoke the main method correctly
  static all(path, handlers) {
    app.all(path, (req, res) => handlers.main(req, res));
  }

  static validateInput() {
    return [
      body('param').isString().escape(),
      // Add more validation rules as needed
    ];
  }

  static handleValidationResults(req, res, next) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }
    next();
  }

  static start() {
    app.use(express.json());
    app.use(helmet());

    // Your default error-handling middleware
    app.use((err, req, res, next) => {
      console.error(err.stack);
      res.status(500).send('Internal Server Error');
    });

    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  }
}

module.exports = Router;
