class Controller {

}
module.exports = Controller;