const Model = require('./Model');

class Test extends Model {

}




module.exports = Test;