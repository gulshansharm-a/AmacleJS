const Router = require('../../src/Amacle/api/Router')
const Test = require('./Controller/TestController')
Router.get('/test',Test)
Router.start()