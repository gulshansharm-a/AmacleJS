

const Controller = require("../../../src/Amacle/api/Controller");
const Test = require('../../../src/Amacle/Models/Test')
class TestController extends Controller {
    /**
     * Handle the main request for the Test route.
     * @static
     * @param {express.Request} req - The Express request object.
     * @param {express.Response} res - The Express response object.
     * @returns {void}
     */
    static main(req, res) {

        // Write your code here
        const t = new Test();
        t.select("*").get().then(result=>{
            res.send(result);

        })
     }
}
        
module.exports = TestController;
        

