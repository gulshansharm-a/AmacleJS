const fs = require('fs');
const path = require('path');

function parseEnvFile(filePath) {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const lines = content.split('\n');
    
    lines.forEach((line) => {
      const trimmedLine = line.trim();
      if (trimmedLine && !trimmedLine.startsWith('#')) {
        const [key, value] = trimmedLine.split('=');
        process.env[key] = value;
      }
    });

    console.log('.env file successfully loaded.');
  } catch (error) {
    console.error('Error reading .env file:', error.message);
  }
}

// Load environment variables from .env file in the project root
require("..")
const envFilePath = path.resolve(__dirname, '../.env');
parseEnvFile(envFilePath);
