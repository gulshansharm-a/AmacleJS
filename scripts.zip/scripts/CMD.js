const fs = require('fs');
const path = require('path');
class CMD {
//     static create(nameOfTable, basePath) {
//         const migrationsPath = path.join(basePath, 'Migrations');
//         const filePath = path.join(migrationsPath, `${nameOfTable}Migration.js`);

//         const dataToWrite = `
// const Blueprint = require("../schema/Blueprint");
// const DB = require("../schema/DB");
// const Migrations = require("../schema/Migration");

// /**
//  * Migration class represents a migration for creating the ${nameOfTable} table.
//  * @extends Migrations
//  */
// class ${nameOfTable}Migration extends Migrations {
//     /**
//      * Initializes the migration by creating the ${nameOfTable} table using a Blueprint.
//      * @override
//      * @returns {void}
//      */
//     initialize() {
//         // Create a new table in the database using a Blueprint
//         DB.create((table = new Blueprint()) => {
//             // Define the structure of the '${nameOfTable}' table
//             table.name("${nameOfTable}");
//             table.id("id");

//             // Execute the SQL query to create the table
//             table.create();
//         });
//     }
    
//     /**
//      * Placeholder for additional actions after the migration.
//      * @override
//      * @returns {void}
//      */
//     action() { 
//         // You can add specific actions or modifications here
//     }
// }

// module.exports = ${nameOfTable}Migration;
// `;

//         // Ensure the migrations directory exists
//         if (!fs.existsSync(migrationsPath)) {
//             fs.mkdirSync(migrationsPath, { recursive: true });
//         }

//         fs.writeFile(filePath, dataToWrite, (err) => {
//             if (err) {
//                 console.error('Error Creating Migration:', err);
//             } else {
//                 console.log(`Migration created successfully: ${filePath}`);
//             }
//         });
//     }
    static createMigration(nameOfTable, basePath) {
        const migrationsPath = path.join(basePath, 'Migrations');
        const filePath = path.join(migrationsPath, `${nameOfTable}Migration.js`);

        const dataToWrite = `
const Blueprint = require("../schema/Blueprint");
const DB = require("../schema/DB");
const Migrations = require("../schema/Migration");

/**
 * Migration class represents a migration for creating the ${nameOfTable} table.
 * @extends Migrations
 */
class ${nameOfTable}Migration extends Migrations {
    /**
     * Initializes the migration by creating the ${nameOfTable} table using a Blueprint.
     * @override
     * @returns {void}
     */
    initialize() {
        // Create a new table in the database using a Blueprint
        DB.create((table = new Blueprint()) => {
            // Define the structure of the '${nameOfTable}' table
            table.name("${nameOfTable}");
            table.id("id");

            // Execute the SQL query to create the table
            table.create();
        });
    }
    
    /**
     * Placeholder for additional actions after the migration.
     * @override
     * @returns {void}
     */
    action() { 
        // You can add specific actions or modifications here
    }
}

module.exports = ${nameOfTable}Migration;
`;

        // Ensure the migrations directory exists
        if (!fs.existsSync(migrationsPath)) {
            fs.mkdirSync(migrationsPath, { recursive: true });
        }

        fs.writeFile(filePath, dataToWrite, (err) => {
            if (err) {
                console.error('Error Creating Migration:', err);
            } else {
                console.log(`Migration created successfully: ${filePath}`);
            }
        });
    }
    static runAllMigrations(basePath) {
        const migrationsPath = basePath;
        fs.readdir(migrationsPath, (err, files) => {
            if (err) {
                console.error('Error [Migration Folder NotFound]:', err);
                return;
            }
    
            console.log('Running Migrations:');
    
            files.forEach((file) => {
                const className = file.replace('.js', '');
                console.log(path.join(migrationsPath, file))
                const modulePath = require.resolve(path.join("../"+migrationsPath, file));
                const MigrationClass = require(modulePath);
    
                if (MigrationClass && typeof MigrationClass === 'function') {
                    // Instantiate the class
                    const instance = new MigrationClass();
                    instance.initialize();
                } else {
                    console.error(`Class '${className}' not found in module.`);
                }
                console.log(className);
            });
        });
    }
    static runOneMigration(basePath,name) {
        const migrationsPath = basePath;
        fs.readdir(migrationsPath, (err, files) => {
            if (err) {
                console.error('Error [Migration Folder NotFound]:', err);
                return;
            }
    
            console.log('Running Migrations:');
    
                const className = name;
                console.log(path.join(migrationsPath, name))
                const modulePath = require.resolve(path.join("../"+migrationsPath, name+"Migration"));
                const MigrationClass = require(modulePath);
    
                if (MigrationClass && typeof MigrationClass === 'function') {
                    // Instantiate the class
                    const instance = new MigrationClass();
                    instance.initialize();
                } else {
                    console.error(`Class '${className}' not found in module.`);
                }
        });
    }
    static runOneMigrationAction(basePath,name) {
        const migrationsPath = basePath;
        fs.readdir(migrationsPath, (err, files) => {
            if (err) {
                console.error('Error [Migration Folder NotFound]:', err);
                return;
            }
    
            console.log('Running Migrations:');
    
                const className = name;
                console.log(path.join(migrationsPath, name))
                const modulePath = require.resolve(path.join("../"+migrationsPath, name+"Migration"));
                const MigrationClass = require(modulePath);
    
                if (MigrationClass && typeof MigrationClass === 'function') {
                    // Instantiate the class
                    const instance = new MigrationClass();
                    instance.action();
                } else {
                    console.error(`Class '${className}' not found in module.`);
                }
        });
    }
    
    // Model 
    static createModel(nameOfTable, basePath) {
        const migrationsPath = path.join(basePath, 'Models');
        const filePath = path.join(migrationsPath, `${nameOfTable}.js`);

        const dataToWrite = `
const Model = require('../data_access/Model');

/**
 * ${nameOfTable} class representing a data model.
 * @class
 * @extends Model
 */
class ${nameOfTable} extends Model {
    // You can add specific properties or methods relevant to your ${nameOfTable} model here.
}

/**
 * Exports the ${nameOfTable} class to make it available for use in other modules.
 * @module
 * @exports ${nameOfTable}
 */
module.exports = ${nameOfTable};

`;

        // Ensure the migrations directory exists
        if (!fs.existsSync(migrationsPath)) {
            fs.mkdirSync(migrationsPath, { recursive: true });
        }

        fs.writeFile(filePath, dataToWrite, (err) => {
            if (err) {
                console.error('Error Creating Model:', err);
            } else {
                console.log(`Model created successfully: ${filePath}`);
            }
        });
    }
    
    //Server
    static createCron(nameOfTable, time) {
        const migrationsPath = path.join(basePath, 'Models');
        const filePath = path.join(migrationsPath, `${nameOfTable}.js`);

        const dataToWrite = `
const Model = require('../data_access/Model');

/**
 * ${nameOfTable} class representing a data model.
 * @class
 * @extends Model
 */
class ${nameOfTable} extends Model {
    // You can add specific properties or methods relevant to your ${nameOfTable} model here.
}

/**
 * Exports the ${nameOfTable} class to make it available for use in other modules.
 * @module
 * @exports ${nameOfTable}
 */
module.exports = ${nameOfTable};

`;

        // Ensure the migrations directory exists
        if (!fs.existsSync(migrationsPath)) {
            fs.mkdirSync(migrationsPath, { recursive: true });
        }

        fs.writeFile(filePath, dataToWrite, (err) => {
            if (err) {
                console.error('Error Creating schedules:', err);
            } else {
                console.log(`schedules created successfully: ${filePath}`);
            }
        });
    }

static apiController(controllernmae, basePath) {
        const controllerPath = path.join(basePath, 'Controller');
        const filePath = path.join(controllerPath, `${controllernmae}.js`);

        const dataToWrite = `

const Controller = require("../../../src/Amacle/api/Controller");

class ${controllernmae} extends Controller {
    /**
     * Handle the main request for the Test route.
     * @static
     * @param {express.Request} req - The Express request object.
     * @param {express.Response} res - The Express response object.
     * @returns {void}
     */
    static main(req, res) {

        // Write your code here
         res.send('Hello!');
     }
}
        
module.exports = ${controllernmae};
        

`;

        // Ensure the migrations directory exists
        if (!fs.existsSync(controllerPath)) {
            fs.mkdirSync(controllerPath, { recursive: true });
        }

        fs.writeFile(filePath, dataToWrite, (err) => {
            if (err) {
                console.error('Error Creating Controller:', err);
            } else {
                console.log(`Controller created successfully: ${filePath}`);
            }
        });
    }
}   


module.exports = CMD;

